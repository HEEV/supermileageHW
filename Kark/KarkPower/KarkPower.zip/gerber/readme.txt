readme.txt - KarkPower folder contents

KarkPower.drl            - Drill File
KarkPower-drl_map.pdf    - Drill Map File
KarkPower-B-Cu.gbr       - Back Copper
KarkPower-B-SilkS.gbr    - Back Silk
KarkPower-F-Cu.gbr       - Front Copper
KarkPower-F-SilkS.gbr    - Front Silk
KarkPower-Edge-Cuts.gbr  - Board Edge
